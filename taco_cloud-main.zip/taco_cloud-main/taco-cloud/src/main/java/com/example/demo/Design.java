package com.example.demo;

import lombok.Data;

@Data
public class Design {
	private String name;
}
