package com.example.demo.security;

public interface UserDetailService {
	//UserDetails loadUseryUserName(String userName) throws UsernameNotFoundException;
}
